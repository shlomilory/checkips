print("hello1\n")
print("hello2\n")