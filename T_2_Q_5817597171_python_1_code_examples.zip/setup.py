# num_of_machines=300 # defining an int
# print("\nnumber of machines:", num_of_machines)
# os_type="linux"     # defining a string
# cpu_temp=41.9
# print("OS type: ", os_type, "\nThe type of cpu_temp is:", type(cpu_temp))

# print("total machines", num_of_machines+10)
# print("total os", int('10')+10) # Type casting

# print(num_of_machines==200)
# num_of_machines=200
# print(num_of_machines==200)

# input from terminal

num_of_machines=input("\nhow many machines? ")
os_type=input("\nOS type? ")

# conditions

if int(num_of_machines)<200 and (os_type is not "linux"):
    print("\nnot enough machines and not linux")
else:
    print("\nthere are 200 machines or more and linux")




