# dictionary: a list of keys and values

machine1={
    "os":"windows",
    "mem":32,
    "cpu":"intel",
    "ip_addresses":["192.168.10.3", "192.168.10.4"]
}

machine2={
    "os":"linux", 
    "mem":64,
    "ip_addresses":["192.168.10.1", "192.168.10.2"]
}

machine1.

my_machines=[machine1, machine2]

def print_os(machine):
    print(machine["os"])

def print_mem(machine):
    print(machine["mem"])

def print_cpu(machine):
    print(machine["cpu"])

def print_all(machine):
    print_mem(machine)
    print_os(machine)
    print(machine.get("cpu", "no_cpu_data"))
    for ip_address in machine["ip_addresses"]:
        print(ip_address)

for machine in my_machines:
    print_all(machine)

