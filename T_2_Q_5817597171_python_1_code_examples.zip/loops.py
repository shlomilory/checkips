# for loop

def loop_example():
    for num in range(1,11):
        print(num)

    os_types=["linux", "windows", "android", "ios"]

    for os_type in os_types:
        print(os_type)

# write a script to get os types from terminal

def list_creator():
    os_types=[]

    os_num=int(input("how many os types (enter a positive number)? "))

    for i in range(0, os_num):
        os_types.append(input("enter os type: "))

    print(os_types)

# functions

def get_id():
    return input("id")

def create_machine(os_type="linux", cpu_type="intel", memory_size=32):
    name="not_tal"
    print(os_type, cpu_type, memory_size, name)




# while loop

# i=0
# while i<10:
#     i+=1
#     print(i)
